#include "adder.h"
using namespace std;
int add(int a, int b) //takes two integers as arguments
{
	return a + b; //returns the sum of the two integers
}